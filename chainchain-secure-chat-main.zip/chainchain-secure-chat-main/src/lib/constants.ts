// ChainChain Smart Contract Constants
// Target Network: Polygon Mumbai Testnet

export const POLYGON_MUMBAI_CHAIN_ID = 80001;
export const POLYGON_MUMBAI_RPC = "https://rpc-mumbai.maticvigil.com";

// Contract Address - Replace with deployed contract address
export const CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000";

// Contract ABI based on the Solidity contract
export const CONTRACT_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "_recipient", "type": "address" },
      { "internalType": "string", "name": "_cid", "type": "string" },
      { "internalType": "bytes", "name": "_signature", "type": "bytes" }
    ],
    "name": "sendMessage",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "_user", "type": "address" }
    ],
    "name": "getMessagesForUser",
    "outputs": [
      {
        "components": [
          { "internalType": "uint256", "name": "id", "type": "uint256" },
          { "internalType": "address", "name": "sender", "type": "address" },
          { "internalType": "address", "name": "recipient", "type": "address" },
          { "internalType": "uint256", "name": "timestamp", "type": "uint256" },
          { "internalType": "string", "name": "cid", "type": "string" },
          { "internalType": "bytes", "name": "signature", "type": "bytes" }
        ],
        "internalType": "struct ChainChain.Message[]",
        "name": "",
        "type": "tuple[]"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": false, "internalType": "uint256", "name": "id", "type": "uint256" },
      { "indexed": true, "internalType": "address", "name": "sender", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "recipient", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256" },
      { "indexed": false, "internalType": "string", "name": "cid", "type": "string" },
      { "indexed": false, "internalType": "bytes", "name": "signature", "type": "bytes" }
    ],
    "name": "MessageSent",
    "type": "event"
  }
] as const;

// EIP-712 Domain for signing messages
export const EIP712_DOMAIN = {
  name: "ChainChain",
  version: "1",
  chainId: POLYGON_MUMBAI_CHAIN_ID,
  verifyingContract: CONTRACT_ADDRESS,
};

// EIP-712 Types for message signing
export const EIP712_TYPES = {
  Message: [
    { name: "recipient", type: "address" },
    { name: "cid", type: "string" },
    { name: "timestamp", type: "uint256" },
  ],
};
